# cs420_project

source code : com.py

version : python3 

사용법 : 

python3 com.py 를 실행한 후에 
">>" -> 이 문자가 뜨면 파일이름.txt(상대경로)을 넣으면 됩니다. -p옵션을 줄 수 있습니다. 
-p 옵션을 주면 DFS로 프린트합니다. 
에러가 있다면 -p옵션과 관계없이 에러를 출력합니다.

필요한 라이브러리 : PLY 3.9
 -> PLY (Python Lex-Yacc)
