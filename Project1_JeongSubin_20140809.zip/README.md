# cs420_project

source code : com.py

version : python3 

사용법 : 

python3 com.py 를 실행한 후에 
"file name : " -> 이 문자가 뜨면 파일이름.txt(상대경로)을 넣으면 됩니다.

결과는 화면에 출력이 되며 만약에 syntax 에러가 있다면 에러 메세지와 그걸 무시한 파싱을 한 결과가 같이 출력이 됩니다.

필요한 라이브러리 : PLY 3.9
 -> PLY (Python Lex-Yacc)
